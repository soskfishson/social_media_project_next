import { cn as a, cm as c } from "./index-Bn9PoSmG.mjs";
export {
  a as startMockingNotes,
  c as startMockingSocial
};
